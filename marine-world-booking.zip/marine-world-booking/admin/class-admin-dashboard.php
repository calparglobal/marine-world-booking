<?php

class MWB_Admin_Dashboard {
    
    private $database;
    private $booking_manager;
    private $payment_handler;
    
    public function __construct() {
        $this->database = new MWB_Database();
        $this->booking_manager = new MWB_Booking_Manager();
        $this->payment_handler = new MWB_Payment_Handler();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'register_settings'));
        
        // AJAX handlers for admin actions
        add_action('wp_ajax_mwb_get_dashboard_stats', array($this, 'get_dashboard_stats'));
        add_action('wp_ajax_mwb_get_bookings_list', array($this, 'get_bookings_list'));
        add_action('wp_ajax_mwb_get_availability_data', array($this, 'get_availability_data'));
        add_action('wp_ajax_mwb_update_availability', array($this, 'update_availability'));
        add_action('wp_ajax_mwb_export_bookings', array($this, 'export_bookings'));
        add_action('wp_ajax_mwb_bulk_action_bookings', array($this, 'bulk_action_bookings'));
        add_action('wp_ajax_mwb_save_settings', array($this, 'save_settings'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Marine World Booking',
            'Marine World',
            'manage_options',
            'marine-world-booking',
            array($this, 'render_dashboard_page'),
            'dashicons-calendar-alt',
            30
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'marine-world-booking',
            array($this, 'render_dashboard_page')
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Bookings',
            'Bookings',
            'manage_options',
            'marine-world-bookings',
            array($this, 'render_bookings_page')
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Availability',
            'Availability',
            'manage_options',
            'marine-world-availability',
            array($this, 'render_availability_page')
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Analytics',
            'Analytics',
            'manage_options',
            'marine-world-analytics',
            array($this, 'render_analytics_page')
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Settings',
            'Settings',
            'manage_options',
            'marine-world-settings',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Add-ons',
            'Add-ons',
            'manage_options',
            'marine-world-addons',
            array($this, 'render_addons_page')
        );
        
        add_submenu_page(
            'marine-world-booking',
            'Promo Codes',
            'Promo Codes',
            'manage_options',
            'marine-world-promo-codes',
            array($this, 'render_promo_codes_page')
        );
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'marine-world') === false) {
            return;
        }
        
        // Enqueue React and dependencies
        wp_enqueue_script('react', 'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js', array(), '18.2.0', true);
        wp_enqueue_script('react-dom', 'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js', array('react'), '18.2.0', true);
        
        // Admin dashboard script
        wp_enqueue_script(
            'marine-world-admin',
            MWB_PLUGIN_URL . 'assets/js/admin-dashboard.js',
            array('react', 'react-dom', 'jquery'),
            MWB_VERSION,
            true
        );
        
        // Admin styles
        wp_enqueue_style(
            'marine-world-admin-styles',
            MWB_PLUGIN_URL . 'assets/css/admin-styles.css',
            array(),
            MWB_VERSION
        );
        
        // WordPress admin styles
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
        
        // Chart.js for analytics
        wp_enqueue_script('chart-js', 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js', array(), '3.9.1', true);
        
        // Localize script with admin data
        wp_localize_script('marine-world-admin', 'marineWorldAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mwb_admin_nonce'),
            'restUrl' => rest_url('marine-world/v1/'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'currentPage' => $_GET['page'] ?? 'marine-world-booking',
            'locations' => $this->database->get_locations(),
            'currency' => '₹',
            'dateFormat' => 'Y-m-d',
            'timeFormat' => 'H:i:s'
        ));
    }
    
    public function register_settings() {
        // General Settings
        register_setting('mwb_general_settings', 'mwb_default_capacity');
        register_setting('mwb_general_settings', 'mwb_max_advance_booking_days');
        register_setting('mwb_general_settings', 'mwb_group_discount_15');
        register_setting('mwb_general_settings', 'mwb_group_discount_30');
        
        // Payment Settings
        register_setting('mwb_payment_settings', 'mwb_icici_merchant_id');
        register_setting('mwb_payment_settings', 'mwb_icici_access_code');
        register_setting('mwb_payment_settings', 'mwb_icici_working_key');
        register_setting('mwb_payment_settings', 'mwb_icici_test_mode');
        
        // Notification Settings
        register_setting('mwb_notification_settings', 'mwb_email_from_name');
        register_setting('mwb_notification_settings', 'mwb_email_from_address');
        register_setting('mwb_notification_settings', 'mwb_sms_provider');
        register_setting('mwb_notification_settings', 'mwb_textlocal_username');
        register_setting('mwb_notification_settings', 'mwb_textlocal_hash');
        register_setting('mwb_notification_settings', 'mwb_msg91_authkey');
        register_setting('mwb_notification_settings', 'mwb_whatsapp_enabled');
    }
    
    // Page Renderers
    public function render_dashboard_page() {
        ?>
        <div class="wrap">
            <h1>Marine World Booking Dashboard</h1>
            <div id="mwb-admin-dashboard"></div>
        </div>
        <?php
    }
    
    public function render_bookings_page() {
        ?>
        <div class="wrap">
            <h1>Bookings Management</h1>
            <div id="mwb-bookings-dashboard"></div>
        </div>
        <?php
    }
    
    public function render_availability_page() {
        ?>
        <div class="wrap">
            <h1>Availability Management</h1>
            <div id="mwb-availability-dashboard"></div>
        </div>
        <?php
    }
    
    public function render_analytics_page() {
        ?>
        <div class="wrap">
            <h1>Analytics & Reports</h1>
            <div id="mwb-analytics-dashboard"></div>
        </div>
        <?php
    }
    
    public function render_addons_page() {
        ?>
        <div class="wrap">
            <h1>Add-ons Management</h1>
            <div id="mwb-addons-dashboard"></div>
        </div>
        <?php
    }
    
    public function render_promo_codes_page() {
        ?>
        <div class="wrap">
            <h1>Promo Codes</h1>
            <div id="mwb-promo-codes-dashboard"></div>
        </div>
        <?php
    }
    
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>Marine World Booking Settings</h1>
            
            <nav class="nav-tab-wrapper">
                <a href="#general" class="nav-tab nav-tab-active">General</a>
                <a href="#payment" class="nav-tab">Payment</a>
                <a href="#notifications" class="nav-tab">Notifications</a>
                <a href="#advanced" class="nav-tab">Advanced</a>
            </nav>
            
            <div id="mwb-settings-dashboard"></div>
            
            <form method="post" action="options.php" id="mwb-settings-form" style="display: none;">
                <?php settings_fields('mwb_general_settings'); ?>
                
                <div id="general-tab" class="tab-content">
                    <h2>General Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Default Capacity</th>
                            <td>
                                <input type="number" name="mwb_default_capacity" value="<?php echo esc_attr(get_option('mwb_default_capacity', 1000)); ?>" min="1" />
                                <p class="description">Default daily capacity for new locations</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Max Advance Booking Days</th>
                            <td>
                                <input type="number" name="mwb_max_advance_booking_days" value="<?php echo esc_attr(get_option('mwb_max_advance_booking_days', 60)); ?>" min="1" max="365" />
                                <p class="description">Maximum days in advance customers can book</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Group Discount (15+ people)</th>
                            <td>
                                <input type="number" name="mwb_group_discount_15" value="<?php echo esc_attr(get_option('mwb_group_discount_15', 5)); ?>" min="0" max="100" step="0.1" />%
                                <p class="description">Discount percentage for groups of 15 or more</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Group Discount (30+ people)</th>
                            <td>
                                <input type="number" name="mwb_group_discount_30" value="<?php echo esc_attr(get_option('mwb_group_discount_30', 10)); ?>" min="0" max="100" step="0.1" />%
                                <p class="description">Discount percentage for groups of 30 or more</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div id="payment-tab" class="tab-content" style="display: none;">
                    <h2>Payment Gateway Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">ICICI Merchant ID</th>
                            <td>
                                <input type="text" name="mwb_icici_merchant_id" value="<?php echo esc_attr(get_option('mwb_icici_merchant_id')); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">ICICI Access Code</th>
                            <td>
                                <input type="text" name="mwb_icici_access_code" value="<?php echo esc_attr(get_option('mwb_icici_access_code')); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">ICICI Working Key</th>
                            <td>
                                <input type="password" name="mwb_icici_working_key" value="<?php echo esc_attr(get_option('mwb_icici_working_key')); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Test Mode</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="mwb_icici_test_mode" value="yes" <?php checked(get_option('mwb_icici_test_mode'), 'yes'); ?> />
                                    Enable test mode
                                </label>
                                <p class="description">Use test environment for payments</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div id="notifications-tab" class="tab-content" style="display: none;">
                    <h2>Notification Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Email From Name</th>
                            <td>
                                <input type="text" name="mwb_email_from_name" value="<?php echo esc_attr(get_option('mwb_email_from_name', 'Marine World')); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Email From Address</th>
                            <td>
                                <input type="email" name="mwb_email_from_address" value="<?php echo esc_attr(get_option('mwb_email_from_address', 'noreply@marineworld.in')); ?>" class="regular-text" />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">SMS Provider</th>
                            <td>
                                <select name="mwb_sms_provider">
                                    <option value="none" <?php selected(get_option('mwb_sms_provider'), 'none'); ?>>None</option>
                                    <option value="textlocal" <?php selected(get_option('mwb_sms_provider'), 'textlocal'); ?>>Textlocal</option>
                                    <option value="msg91" <?php selected(get_option('mwb_sms_provider'), 'msg91'); ?>>MSG91</option>
                                    <option value="twilio" <?php selected(get_option('mwb_sms_provider'), 'twilio'); ?>>Twilio</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">WhatsApp Notifications</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="mwb_whatsapp_enabled" value="yes" <?php checked(get_option('mwb_whatsapp_enabled'), 'yes'); ?> />
                                    Enable WhatsApp notifications
                                </label>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div id="advanced-tab" class="tab-content" style="display: none;">
                    <h2>Advanced Settings</h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row">Debug Mode</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="mwb_debug_mode" value="yes" <?php checked(get_option('mwb_debug_mode'), 'yes'); ?> />
                                    Enable debug logging
                                </label>
                                <p class="description">Log detailed information for troubleshooting</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Cache Duration</th>
                            <td>
                                <input type="number" name="mwb_cache_duration" value="<?php echo esc_attr(get_option('mwb_cache_duration', 300)); ?>" min="60" max="3600" /> seconds
                                <p class="description">How long to cache availability data</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <?php submit_button(); ?>
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('.nav-tab').click(function(e) {
                e.preventDefault();
                var target = $(this).attr('href');
                
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                $('.tab-content').hide();
                $(target + '-tab').show();
            });
        });
        </script>
        <?php
    }
    
    // AJAX Handlers
    public function get_dashboard_stats() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $date_from = sanitize_text_field($_POST['date_from'] ?? date('Y-m-01'));
        $date_to = sanitize_text_field($_POST['date_to'] ?? date('Y-m-d'));
        
        // Get basic stats
        $stats = $this->database->get_booking_stats(null, $date_from, $date_to);
        
        // Get recent bookings
        $recent_bookings = $this->database->get_bookings(5, 0);
        
        // Get today's stats
        $today_stats = $this->database->get_booking_stats(null, date('Y-m-d'), date('Y-m-d'));
        
        // Get payment analytics
        $payment_analytics = $this->payment_handler->get_payment_analytics($date_from, $date_to);
        
        // Get upcoming events (next 7 days with bookings)
        global $wpdb;
        $bookings_table = $wpdb->prefix . 'mwb_bookings';
        
        $upcoming_events = $wpdb->get_results(
            "SELECT booking_date, COUNT(*) as booking_count, SUM(general_tickets + child_tickets + senior_tickets) as total_visitors
             FROM {$bookings_table} 
             WHERE booking_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
             AND booking_status = 'confirmed'
             GROUP BY booking_date 
             ORDER BY booking_date"
        );
        
        wp_send_json_success(array(
            'stats' => $stats,
            'recent_bookings' => $recent_bookings,
            'today_stats' => $today_stats,
            'payment_analytics' => $payment_analytics,
            'upcoming_events' => $upcoming_events
        ));
    }
    
    public function get_bookings_list() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $page = intval($_POST['page'] ?? 1);
        $per_page = intval($_POST['per_page'] ?? 20);
        $search = sanitize_text_field($_POST['search'] ?? '');
        $filters = array(
            'date_from' => sanitize_text_field($_POST['date_from'] ?? ''),
            'date_to' => sanitize_text_field($_POST['date_to'] ?? ''),
            'location_id' => intval($_POST['location_id'] ?? 0),
            'status' => sanitize_text_field($_POST['status'] ?? '')
        );
        
        $offset = ($page - 1) * $per_page;
        
        if (!empty($search)) {
            $bookings = $this->booking_manager->search_bookings($search, $filters);
        } else {
            $bookings = $this->database->get_bookings($per_page, $offset, $filters);
        }
        
        // Get total count for pagination
        global $wpdb;
        $bookings_table = $wpdb->prefix . 'mwb_bookings';
        $total_count = $wpdb->get_var("SELECT COUNT(*) FROM {$bookings_table}");
        
        wp_send_json_success(array(
            'bookings' => $bookings,
            'total_count' => $total_count,
            'total_pages' => ceil($total_count / $per_page),
            'current_page' => $page
        ));
    }
    
    public function get_availability_data() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $location_id = intval($_POST['location_id'] ?? 1);
        $date_from = sanitize_text_field($_POST['date_from'] ?? date('Y-m-01'));
        $date_to = sanitize_text_field($_POST['date_to'] ?? date('Y-m-t'));
        
        $availability = $this->database->get_availability($location_id, $date_from, $date_to);
        
        wp_send_json_success($availability);
    }
    
    public function update_availability() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $location_id = intval($_POST['location_id']);
        $date = sanitize_text_field($_POST['date']);
        $capacity = intval($_POST['capacity']);
        $is_blackout = isset($_POST['is_blackout']) ? 1 : 0;
        $special_pricing = floatval($_POST['special_pricing'] ?? 0);
        
        $result = $this->booking_manager->update_location_capacity($location_id, $date, $capacity);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        
        // Update additional settings
        global $wpdb;
        $availability_table = $wpdb->prefix . 'mwb_availability';
        
        $update_data = array();
        if ($is_blackout) {
            $update_data['is_blackout'] = 1;
            $update_data['status'] = 'blackout';
        }
        if ($special_pricing > 0) {
            $update_data['special_pricing'] = $special_pricing;
        }
        
        if (!empty($update_data)) {
            $wpdb->update(
                $availability_table,
                $update_data,
                array('location_id' => $location_id, 'availability_date' => $date)
            );
        }
        
        wp_send_json_success('Availability updated successfully');
    }
    
    public function export_bookings() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $format = sanitize_text_field($_POST['format'] ?? 'csv');
        $filters = array(
            'date_from' => sanitize_text_field($_POST['date_from'] ?? ''),
            'date_to' => sanitize_text_field($_POST['date_to'] ?? ''),
            'location_id' => intval($_POST['location_id'] ?? 0),
            'status' => sanitize_text_field($_POST['status'] ?? '')
        );
        
        $report = $this->booking_manager->generate_booking_report($format, $filters);
        
        wp_send_json_success($report);
    }
    
    public function bulk_action_bookings() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $booking_ids = array_map('sanitize_text_field', $_POST['booking_ids'] ?? array());
        $action = sanitize_text_field($_POST['action']);
        $data = array(
            'reason' => sanitize_textarea_field($_POST['reason'] ?? '')
        );
        
        if (empty($booking_ids) || empty($action)) {
            wp_send_json_error('Missing required parameters');
        }
        
        $result = $this->booking_manager->bulk_update_bookings($booking_ids, $action, $data);
        
        wp_send_json_success($result);
    }
    
    public function save_settings() {
        check_ajax_referer('mwb_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        $settings = $_POST['settings'] ?? array();
        
        foreach ($settings as $key => $value) {
            $sanitized_key = sanitize_key($key);
            $sanitized_value = is_array($value) ? array_map('sanitize_text_field', $value) : sanitize_text_field($value);
            update_option($sanitized_key, $sanitized_value);
        }
        
        wp_send_json_success('Settings saved successfully');
    }
    
    // Helper methods
    public function get_booking_status_options() {
        return array(
            'pending' => 'Pending',
            'confirmed' => 'Confirmed',
            'cancelled' => 'Cancelled',
            'refunded' => 'Refunded',
            'expired' => 'Expired'
        );
    }
    
    public function get_payment_status_options() {
        return array(
            'pending' => 'Pending',
            'completed' => 'Completed',
            'failed' => 'Failed',
            'refunded' => 'Refunded'
        );
    }
}

// Initialize admin dashboard
if (is_admin()) {
    new MWB_Admin_Dashboard();
}
?>