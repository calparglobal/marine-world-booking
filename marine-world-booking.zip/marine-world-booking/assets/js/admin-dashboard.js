// Marine World Booking Admin Dashboard
(function() {
    'use strict';

    // Check if React is available
    if (typeof React === 'undefined' || typeof ReactDOM === 'undefined') {
        console.error('Marine World Admin: React is not loaded');
        return;
    }

    const { useState, useEffect, useCallback } = React;
    const { render } = ReactDOM;

    // API Helper Functions
    const adminApi = {
        async request(action, data = {}) {
            const formData = new FormData();
            formData.append('action', action);
            formData.append('nonce', marineWorldAdmin.nonce);
            
            Object.keys(data).forEach(key => {
                if (Array.isArray(data[key])) {
                    data[key].forEach(item => formData.append(`${key}[]`, item));
                } else {
                    formData.append(key, data[key]);
                }
            });

            try {
                const response = await fetch(marineWorldAdmin.ajaxUrl, {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (!result.success) {
                    throw new Error(result.data || 'Request failed');
                }
                
                return result.data;
            } catch (error) {
                console.error('Admin API Error:', error);
                throw error;
            }
        },

        getDashboardStats(dateFrom, dateTo) {
            return this.request('mwb_get_dashboard_stats', { date_from: dateFrom, date_to: dateTo });
        },

        getBookingsList(page = 1, perPage = 20, search = '', filters = {}) {
            return this.request('mwb_get_bookings_list', { 
                page, 
                per_page: perPage, 
                search, 
                ...filters 
            });
        },

        getAvailabilityData(locationId, dateFrom, dateTo) {
            return this.request('mwb_get_availability_data', { 
                location_id: locationId,
                date_from: dateFrom,
                date_to: dateTo 
            });
        },

        updateAvailability(locationId, date, capacity, isBlackout = false, specialPricing = 0) {
            return this.request('mwb_update_availability', {
                location_id: locationId,
                date,
                capacity,
                is_blackout: isBlackout,
                special_pricing: specialPricing
            });
        },

        exportBookings(format, filters) {
            return this.request('mwb_export_bookings', { format, ...filters });
        },

        bulkActionBookings(bookingIds, action, data = {}) {
            return this.request('mwb_bulk_action_bookings', {
                booking_ids: bookingIds,
                action,
                ...data
            });
        },

        saveSettings(settings) {
            return this.request('mwb_save_settings', { settings });
        }
    };

    // Utility Functions
    const utils = {
        formatCurrency(amount) {
            return `${marineWorldAdmin.currency}${parseFloat(amount).toLocaleString('en-IN')}`;
        },

        formatDate(date) {
            return new Date(date).toLocaleDateString('en-IN', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        },

        formatDateTime(datetime) {
            return new Date(datetime).toLocaleString('en-IN', {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        },

        debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    };

    // Components
    const LoadingSpinner = () => React.createElement('div', { className: 'mwb-admin-loading' },
        React.createElement('div', { className: 'mwb-spinner' }),
        React.createElement('span', null, 'Loading...')
    );

    const StatsCard = ({ title, value, icon, trend, trendValue }) => {
        return React.createElement('div', { className: 'mwb-stats-card' },
            React.createElement('div', { className: 'mwb-stats-header' },
                React.createElement('h3', null, title),
                React.createElement('span', { className: `mwb-stats-icon ${icon}` })
            ),
            React.createElement('div', { className: 'mwb-stats-value' }, value),
            trend && React.createElement('div', { 
                className: `mwb-stats-trend ${trend > 0 ? 'positive' : 'negative'}` 
            },
                React.createElement('span', null, `${trend > 0 ? '+' : ''}${trendValue}`)
            )
        );
    };

    // Dashboard Component
    const Dashboard = () => {
        const [stats, setStats] = useState(null);
        const [loading, setLoading] = useState(true);
        const [dateRange, setDateRange] = useState({
            from: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
            to: new Date().toISOString().split('T')[0]
        });

        const loadStats = useCallback(async () => {
            try {
                setLoading(true);
                const data = await adminApi.getDashboardStats(dateRange.from, dateRange.to);
                setStats(data);
            } catch (error) {
                console.error('Failed to load stats:', error);
            } finally {
                setLoading(false);
            }
        }, [dateRange]);

        useEffect(() => {
            loadStats();
        }, [loadStats]);

        if (loading) return React.createElement(LoadingSpinner);

        return React.createElement('div', { className: 'mwb-dashboard' },
            React.createElement('div', { className: 'mwb-dashboard-header' },
                React.createElement('h2', null, 'Dashboard Overview'),
                React.createElement('div', { className: 'mwb-date-filters' },
                    React.createElement('input', {
                        type: 'date',
                        value: dateRange.from,
                        onChange: (e) => setDateRange(prev => ({ ...prev, from: e.target.value }))
                    }),
                    React.createElement('input', {
                        type: 'date',
                        value: dateRange.to,
                        onChange: (e) => setDateRange(prev => ({ ...prev, to: e.target.value }))
                    }),
                    React.createElement('button', {
                        className: 'button button-primary',
                        onClick: loadStats
                    }, 'Update')
                )
            ),
            
            stats && React.createElement('div', { className: 'mwb-stats-grid' },
                React.createElement(StatsCard, {
                    title: 'Total Bookings',
                    value: stats.stats?.total_bookings || 0,
                    icon: 'dashicons-calendar-alt'
                }),
                React.createElement(StatsCard, {
                    title: 'Total Revenue',
                    value: utils.formatCurrency(stats.stats?.total_revenue || 0),
                    icon: 'dashicons-money-alt'
                }),
                React.createElement(StatsCard, {
                    title: 'Total Tickets',
                    value: stats.stats?.total_tickets || 0,
                    icon: 'dashicons-tickets-alt'
                }),
                React.createElement(StatsCard, {
                    title: 'Average Booking Value',
                    value: utils.formatCurrency(stats.stats?.average_booking_value || 0),
                    icon: 'dashicons-chart-line'
                })
            ),

            React.createElement('div', { className: 'mwb-dashboard-grid' },
                React.createElement('div', { className: 'mwb-recent-bookings' },
                    React.createElement('h3', null, 'Recent Bookings'),
                    stats.recent_bookings && stats.recent_bookings.length > 0 ?
                        React.createElement('div', { className: 'mwb-bookings-list' },
                            stats.recent_bookings.map(booking =>
                                React.createElement('div', { 
                                    key: booking.id, 
                                    className: 'mwb-booking-item' 
                                },
                                    React.createElement('div', { className: 'mwb-booking-info' },
                                        React.createElement('strong', null, booking.booking_id),
                                        React.createElement('span', null, booking.customer_name),
                                        React.createElement('span', null, utils.formatDate(booking.booking_date))
                                    ),
                                    React.createElement('div', { className: 'mwb-booking-amount' },
                                        utils.formatCurrency(booking.total_amount)
                                    ),
                                    React.createElement('div', { 
                                        className: `mwb-booking-status ${booking.booking_status}` 
                                    }, booking.booking_status)
                                )
                            )
                        ) : React.createElement('p', null, 'No recent bookings')
                ),

                React.createElement('div', { className: 'mwb-upcoming-events' },
                    React.createElement('h3', null, 'Upcoming Events (Next 7 Days)'),
                    stats.upcoming_events && stats.upcoming_events.length > 0 ?
                        React.createElement('div', { className: 'mwb-events-list' },
                            stats.upcoming_events.map(event =>
                                React.createElement('div', { 
                                    key: event.booking_date, 
                                    className: 'mwb-event-item' 
                                },
                                    React.createElement('div', { className: 'mwb-event-date' },
                                        utils.formatDate(event.booking_date)
                                    ),
                                    React.createElement('div', { className: 'mwb-event-stats' },
                                        React.createElement('span', null, `${event.booking_count} bookings`),
                                        React.createElement('span', null, `${event.total_visitors} visitors`)
                                    )
                                )
                            )
                        ) : React.createElement('p', null, 'No upcoming events')
                )
            )
        );
    };

    // Bookings Management Component
    const BookingsManagement = () => {
        const [bookings, setBookings] = useState([]);
        const [loading, setLoading] = useState(true);
        const [pagination, setPagination] = useState({ current: 1, total: 1, perPage: 20 });
        const [search, setSearch] = useState('');
        const [filters, setFilters] = useState({
            date_from: '',
            date_to: '',
            location_id: '',
            status: ''
        });
        const [selectedBookings, setSelectedBookings] = useState([]);
        const [bulkAction, setBulkAction] = useState('');

        const loadBookings = useCallback(async (page = 1) => {
            try {
                setLoading(true);
                const data = await adminApi.getBookingsList(page, pagination.perPage, search, filters);
                setBookings(data.bookings);
                setPagination({
                    current: data.current_page,
                    total: data.total_pages,
                    perPage: pagination.perPage
                });
            } catch (error) {
                console.error('Failed to load bookings:', error);
            } finally {
                setLoading(false);
            }
        }, [search, filters, pagination.perPage]);

        const debouncedSearch = useCallback(
            utils.debounce(() => loadBookings(1), 500),
            [loadBookings]
        );

        useEffect(() => {
            debouncedSearch();
        }, [debouncedSearch]);

        const handleBulkAction = async () => {
            if (!bulkAction || selectedBookings.length === 0) return;

            const reason = bulkAction === 'cancel' ? 
                prompt('Please enter cancellation reason:') : '';

            if (bulkAction === 'cancel' && !reason) return;

            try {
                await adminApi.bulkActionBookings(selectedBookings, bulkAction, { reason });
                setSelectedBookings([]);
                setBulkAction('');
                loadBookings(pagination.current);
                alert('Bulk action completed successfully');
            } catch (error) {
                alert('Bulk action failed: ' + error.message);
            }
        };

        const handleExport = async (format) => {
            try {
                const result = await adminApi.exportBookings(format, filters);
                if (result.file_url) {
                    window.open(result.file_url, '_blank');
                }
            } catch (error) {
                alert('Export failed: ' + error.message);
            }
        };

        return React.createElement('div', { className: 'mwb-bookings-management' },
            React.createElement('div', { className: 'mwb-bookings-header' },
                React.createElement('div', { className: 'mwb-search-filters' },
                    React.createElement('input', {
                        type: 'text',
                        placeholder: 'Search bookings...',
                        value: search,
                        onChange: (e) => setSearch(e.target.value),
                        className: 'mwb-search-input'
                    }),
                    React.createElement('input', {
                        type: 'date',
                        value: filters.date_from,
                        onChange: (e) => setFilters(prev => ({ ...prev, date_from: e.target.value })),
                        placeholder: 'From Date'
                    }),
                    React.createElement('input', {
                        type: 'date',
                        value: filters.date_to,
                        onChange: (e) => setFilters(prev => ({ ...prev, date_to: e.target.value })),
                        placeholder: 'To Date'
                    }),
                    React.createElement('select', {
                        value: filters.status,
                        onChange: (e) => setFilters(prev => ({ ...prev, status: e.target.value }))
                    },
                        React.createElement('option', { value: '' }, 'All Statuses'),
                        React.createElement('option', { value: 'pending' }, 'Pending'),
                        React.createElement('option', { value: 'confirmed' }, 'Confirmed'),
                        React.createElement('option', { value: 'cancelled' }, 'Cancelled'),
                        React.createElement('option', { value: 'refunded' }, 'Refunded')
                    )
                ),
                React.createElement('div', { className: 'mwb-bulk-actions' },
                    React.createElement('select', {
                        value: bulkAction,
                        onChange: (e) => setBulkAction(e.target.value)
                    },
                        React.createElement('option', { value: '' }, 'Bulk Actions'),
                        React.createElement('option', { value: 'cancel' }, 'Cancel'),
                        React.createElement('option', { value: 'resend_confirmation' }, 'Resend Confirmation'),
                        React.createElement('option', { value: 'mark_claimed' }, 'Mark as Claimed')
                    ),
                    React.createElement('button', {
                        className: 'button',
                        onClick: handleBulkAction,
                        disabled: !bulkAction || selectedBookings.length === 0
                    }, 'Apply'),
                    React.createElement('button', {
                        className: 'button',
                        onClick: () => handleExport('csv')
                    }, 'Export CSV')
                )
            ),

            loading ? React.createElement(LoadingSpinner) :
                React.createElement('div', { className: 'mwb-bookings-table-wrapper' },
                    React.createElement('table', { className: 'wp-list-table widefat fixed striped' },
                        React.createElement('thead', null,
                            React.createElement('tr', null,
                                React.createElement('td', { className: 'manage-column column-cb check-column' },
                                    React.createElement('input', {
                                        type: 'checkbox',
                                        onChange: (e) => {
                                            if (e.target.checked) {
                                                setSelectedBookings(bookings.map(b => b.booking_id));
                                            } else {
                                                setSelectedBookings([]);
                                            }
                                        }
                                    })
                                ),
                                React.createElement('th', null, 'Booking ID'),
                                React.createElement('th', null, 'Customer'),
                                React.createElement('th', null, 'Date'),
                                React.createElement('th', null, 'Tickets'),
                                React.createElement('th', null, 'Amount'),
                                React.createElement('th', null, 'Status'),
                                React.createElement('th', null, 'Actions')
                            )
                        ),
                        React.createElement('tbody', null,
                            bookings.map(booking =>
                                React.createElement('tr', { key: booking.id },
                                    React.createElement('th', { className: 'check-column' },
                                        React.createElement('input', {
                                            type: 'checkbox',
                                            checked: selectedBookings.includes(booking.booking_id),
                                            onChange: (e) => {
                                                if (e.target.checked) {
                                                    setSelectedBookings(prev => [...prev, booking.booking_id]);
                                                } else {
                                                    setSelectedBookings(prev => prev.filter(id => id !== booking.booking_id));
                                                }
                                            }
                                        })
                                    ),
                                    React.createElement('td', null,
                                        React.createElement('strong', null, booking.booking_id)
                                    ),
                                    React.createElement('td', null,
                                        React.createElement('div', null, booking.customer_name),
                                        React.createElement('div', { className: 'mwb-customer-contact' },
                                            booking.customer_email
                                        )
                                    ),
                                    React.createElement('td', null, utils.formatDate(booking.booking_date)),
                                    React.createElement('td', null, booking.total_tickets || 
                                        (parseInt(booking.general_tickets || 0) + 
                                         parseInt(booking.child_tickets || 0) + 
                                         parseInt(booking.senior_tickets || 0))
                                    ),
                                    React.createElement('td', null, utils.formatCurrency(booking.total_amount)),
                                    React.createElement('td', null,
                                        React.createElement('span', { 
                                            className: `mwb-status-badge ${booking.booking_status}` 
                                        }, booking.booking_status)
                                    ),
                                    React.createElement('td', null,
                                        React.createElement('div', { className: 'mwb-booking-actions' },
                                            React.createElement('button', {
                                                className: 'button button-small',
                                                onClick: () => window.open(`${marineWorldAdmin.restUrl}booking/${booking.booking_id}`, '_blank')
                                            }, 'View'),
                                            booking.booking_status === 'confirmed' && 
                                                React.createElement('button', {
                                                    className: 'button button-small',
                                                    onClick: async () => {
                                                        try {
                                                            await adminApi.bulkActionBookings([booking.booking_id], 'resend_confirmation');
                                                            alert('Confirmation resent successfully');
                                                        } catch (error) {
                                                            alert('Failed to resend confirmation');
                                                        }
                                                    }
                                                }, 'Resend')
                                        )
                                    )
                                )
                            )
                        )
                    )
                ),

            React.createElement('div', { className: 'mwb-pagination' },
                pagination.current > 1 &&
                    React.createElement('button', {
                        className: 'button',
                        onClick: () => loadBookings(pagination.current - 1)
                    }, 'Previous'),
                React.createElement('span', { className: 'mwb-pagination-info' },
                    `Page ${pagination.current} of ${pagination.total}`
                ),
                pagination.current < pagination.total &&
                    React.createElement('button', {
                        className: 'button',
                        onClick: () => loadBookings(pagination.current + 1)
                    }, 'Next')
            )
        );
    };

    // Availability Management Component
    const AvailabilityManagement = () => {
        const [availability, setAvailability] = useState([]);
        const [loading, setLoading] = useState(true);
        const [selectedLocation, setSelectedLocation] = useState(marineWorldAdmin.locations[0]?.id || 1);
        const [currentMonth, setCurrentMonth] = useState(new Date());
        const [editingDate, setEditingDate] = useState(null);
        const [editForm, setEditForm] = useState({
            capacity: '',
            isBlackout: false,
            specialPricing: ''
        });

        const loadAvailability = useCallback(async () => {
            try {
                setLoading(true);
                const startDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
                const endDate = new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1, 0);
                
                const data = await adminApi.getAvailabilityData(
                    selectedLocation,
                    startDate.toISOString().split('T')[0],
                    endDate.toISOString().split('T')[0]
                );
                setAvailability(data);
            } catch (error) {
                console.error('Failed to load availability:', error);
            } finally {
                setLoading(false);
            }
        }, [selectedLocation, currentMonth]);

        useEffect(() => {
            loadAvailability();
        }, [loadAvailability]);

        const handleEditDate = (date) => {
            const dayData = availability.find(d => d.date === date);
            setEditingDate(date);
            setEditForm({
                capacity: dayData?.total_capacity || 1000,
                isBlackout: dayData?.is_blackout || false,
                specialPricing: dayData?.special_pricing || ''
            });
        };

        const handleSaveDate = async () => {
            try {
                await adminApi.updateAvailability(
                    selectedLocation,
                    editingDate,
                    editForm.capacity,
                    editForm.isBlackout,
                    editForm.specialPricing
                );
                setEditingDate(null);
                loadAvailability();
                alert('Availability updated successfully');
            } catch (error) {
                alert('Failed to update availability: ' + error.message);
            }
        };

        const renderCalendar = () => {
            const year = currentMonth.getFullYear();
            const month = currentMonth.getMonth();
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            
            const days = [];
            const startDate = new Date(firstDay);
            startDate.setDate(startDate.getDate() - firstDay.getDay());
            
            for (let i = 0; i < 42; i++) {
                const date = new Date(startDate);
                date.setDate(startDate.getDate() + i);
                days.push(date);
            }

            return days.map((date, index) => {
                const dateStr = date.toISOString().split('T')[0];
                const dayData = availability.find(d => d.date === dateStr);
                const isCurrentMonth = date.getMonth() === month;
                const isToday = date.toDateString() === new Date().toDateString();
                
                let className = 'mwb-calendar-day';
                if (!isCurrentMonth) className += ' other-month';
                if (isToday) className += ' today';
                if (dayData?.is_blackout) className += ' blackout';
                else if (dayData?.status) className += ` ${dayData.status}`;

                return React.createElement('div', {
                    key: index,
                    className,
                    onClick: isCurrentMonth ? () => handleEditDate(dateStr) : null
                },
                    React.createElement('div', { className: 'date-number' }, date.getDate()),
                    dayData && React.createElement('div', { className: 'availability-info' },
                        React.createElement('div', null, `${dayData.available_slots}/${dayData.total_capacity}`),
                        dayData.special_pricing && 
                            React.createElement('div', { className: 'special-price' }, 
                                utils.formatCurrency(dayData.special_pricing)
                            )
                    )
                );
            });
        };

        return React.createElement('div', { className: 'mwb-availability-management' },
            React.createElement('div', { className: 'mwb-availability-header' },
                React.createElement('div', { className: 'mwb-location-selector' },
                    React.createElement('label', null, 'Location: '),
                    React.createElement('select', {
                        value: selectedLocation,
                        onChange: (e) => setSelectedLocation(parseInt(e.target.value))
                    },
                        marineWorldAdmin.locations.map(location =>
                            React.createElement('option', { 
                                key: location.id, 
                                value: location.id 
                            }, location.name)
                        )
                    )
                ),
                React.createElement('div', { className: 'mwb-month-navigation' },
                    React.createElement('button', {
                        className: 'button',
                        onClick: () => setCurrentMonth(prev => {
                            const newMonth = new Date(prev);
                            newMonth.setMonth(prev.getMonth() - 1);
                            return newMonth;
                        })
                    }, '‹ Previous'),
                    React.createElement('h3', null, 
                        currentMonth.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
                    ),
                    React.createElement('button', {
                        className: 'button',
                        onClick: () => setCurrentMonth(prev => {
                            const newMonth = new Date(prev);
                            newMonth.setMonth(prev.getMonth() + 1);
                            return newMonth;
                        })
                    }, 'Next ›')
                )
            ),

            loading ? React.createElement(LoadingSpinner) :
                React.createElement('div', { className: 'mwb-availability-calendar' },
                    React.createElement('div', { className: 'mwb-calendar-weekdays' },
                        ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day =>
                            React.createElement('div', { key: day, className: 'mwb-weekday' }, day)
                        )
                    ),
                    React.createElement('div', { className: 'mwb-calendar-grid' }, renderCalendar())
                ),

            editingDate && React.createElement('div', { className: 'mwb-edit-modal' },
                React.createElement('div', { className: 'mwb-modal-content' },
                    React.createElement('h3', null, `Edit Availability - ${utils.formatDate(editingDate)}`),
                    React.createElement('div', { className: 'mwb-form-group' },
                        React.createElement('label', null, 'Capacity:'),
                        React.createElement('input', {
                            type: 'number',
                            value: editForm.capacity,
                            onChange: (e) => setEditForm(prev => ({ ...prev, capacity: parseInt(e.target.value) }))
                        })
                    ),
                    React.createElement('div', { className: 'mwb-form-group' },
                        React.createElement('label', null,
                            React.createElement('input', {
                                type: 'checkbox',
                                checked: editForm.isBlackout,
                                onChange: (e) => setEditForm(prev => ({ ...prev, isBlackout: e.target.checked }))
                            }),
                            ' Blackout Date'
                        )
                    ),
                    React.createElement('div', { className: 'mwb-form-group' },
                        React.createElement('label', null, 'Special Pricing:'),
                        React.createElement('input', {
                            type: 'number',
                            step: '0.01',
                            value: editForm.specialPricing,
                            onChange: (e) => setEditForm(prev => ({ ...prev, specialPricing: parseFloat(e.target.value) || '' }))
                        })
                    ),
                    React.createElement('div', { className: 'mwb-modal-actions' },
                        React.createElement('button', {
                            className: 'button button-primary',
                            onClick: handleSaveDate
                        }, 'Save'),
                        React.createElement('button', {
                            className: 'button',
                            onClick: () => setEditingDate(null)
                        }, 'Cancel')
                    )
                )
            )
        );
    };

    // Initialize admin components based on current page
    document.addEventListener('DOMContentLoaded', function() {
        const currentPage = marineWorldAdmin.currentPage;

        switch (currentPage) {
            case 'marine-world-booking':
                const dashboardElement = document.getElementById('mwb-admin-dashboard');
                if (dashboardElement) {
                    render(React.createElement(Dashboard), dashboardElement);
                }
                break;

            case 'marine-world-bookings':
                const bookingsElement = document.getElementById('mwb-bookings-dashboard');
                if (bookingsElement) {
                    render(React.createElement(BookingsManagement), bookingsElement);
                }
                break;

            case 'marine-world-availability':
                const availabilityElement = document.getElementById('mwb-availability-dashboard');
                if (availabilityElement) {
                    render(React.createElement(AvailabilityManagement), availabilityElement);
                }
                break;

            // Add more cases for other admin pages as needed
        }
    });

})();