<?php
/**
 * Marine World Booking REST API Class
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class MWB_REST_API {
    
    private $database;
    private $namespace = 'marine-world/v1';
    
    public function __construct() {
        $this->database = new MWB_Database();
    }
    
    /**
     * Initialize REST API
     */
    public function init() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        // Locations endpoints
        register_rest_route($this->namespace, '/locations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_locations'),
            'permission_callback' => '__return_true',
            'args' => array()
        ));
        
        register_rest_route($this->namespace, '/locations/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_location'),
            'permission_callback' => '__return_true',
            'args' => array(
                'id' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                )
            )
        ));
        
        // Availability endpoints
        register_rest_route($this->namespace, '/availability', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_availability'),
            'permission_callback' => '__return_true',
            'args' => array(
                'location_id' => array(
                    'required' => true,
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
                'date_from' => array(
                    'required' => true,
                    'validate_callback' => array($this, 'validate_date')
                ),
                'date_to' => array(
                    'required' => false,
                    'validate_callback' => array($this, 'validate_date')
                )
            )
        ));
        
        // Pricing calculation endpoint
        register_rest_route($this->namespace, '/pricing/calculate', array(
            'methods' => 'POST',
            'callback' => array($this, 'calculate_pricing'),
            'permission_callback' => '__return_true',
            'args' => array(
                'tickets' => array('required' => true),
                'addons' => array('required' => false),
                'promo_code' => array('required' => false),
                'booking_date' => array(
                    'required' => true,
                    'validate_callback' => array($this, 'validate_date')
                )
            )
        ));
        
        // Promo code validation
        register_rest_route($this->namespace, '/promo-code/validate', array(
            'methods' => 'POST',
            'callback' => array($this, 'validate_promo_code'),
            'permission_callback' => '__return_true',
            'args' => array(
                'code' => array('required' => true),
                'amount' => array(
                    'required' => true,
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                )
            )
        ));
        
        // Add-ons endpoint
        register_rest_route($this->namespace, '/addons', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_addons'),
            'permission_callback' => '__return_true'
        ));
        
        // Booking endpoints
        register_rest_route($this->namespace, '/booking', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_booking'),
            'permission_callback' => '__return_true',
            'args' => array(
                'location_id' => array('required' => true),
                'booking_date' => array('required' => true),
                'customer_name' => array('required' => true),
                'customer_email' => array('required' => true),
                'customer_phone' => array('required' => true),
                'customer_pincode' => array('required' => true),
                'tickets' => array('required' => true),
                'addons' => array('required' => false),
                'promo_code' => array('required' => false)
            )
        ));
        
        register_rest_route($this->namespace, '/booking/(?P<booking_id>[a-zA-Z0-9]+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_booking'),
            'permission_callback' => '__return_true',
            'args' => array(
                'booking_id' => array(
                    'validate_callback' => function($param) {
                        return !empty($param);
                    }
                )
            )
        ));
        
        // Payment confirmation endpoint
        register_rest_route($this->namespace, '/booking/(?P<booking_id>[a-zA-Z0-9]+)/payment', array(
            'methods' => 'POST',
            'callback' => array($this, 'confirm_payment'),
            'permission_callback' => '__return_true',
            'args' => array(
                'payment_id' => array('required' => true),
                'payment_status' => array('required' => true)
            )
        ));
        
        // Admin endpoints (require admin permissions)
        register_rest_route($this->namespace, '/admin/bookings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_admin_bookings'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'page' => array('default' => 1),
                'per_page' => array('default' => 20),
                'date_from' => array('required' => false),
                'date_to' => array('required' => false),
                'location_id' => array('required' => false),
                'status' => array('required' => false)
            )
        ));
        
        register_rest_route($this->namespace, '/admin/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_admin_stats'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'location_id' => array('required' => false),
                'date_from' => array('required' => false),
                'date_to' => array('required' => false)
            )
        ));
        
        // Availability management (admin only)
        register_rest_route($this->namespace, '/admin/availability', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_availability'),
            'permission_callback' => array($this, 'check_admin_permission'),
            'args' => array(
                'location_id' => array('required' => true),
                'date' => array('required' => true),
                'capacity' => array('required' => false),
                'status' => array('required' => false),
                'special_pricing' => array('required' => false),
                'is_blackout' => array('required' => false)
            )
        ));
    }
    
    /**
     * Get locations
     */
    public function get_locations($request) {
        try {
            $locations = $this->database->get_locations();
            
            if (empty($locations)) {
                return new WP_Error('no_locations', __('No locations found', 'marine-world-booking'), array('status' => 404));
            }
            
            $formatted_locations = array_map(function($location) {
                return array(
                    'id' => (int) $location->id,
                    'name' => $location->name,
                    'address' => $location->address,
                    'city' => $location->city,
                    'state' => $location->state,
                    'pincode' => $location->pincode,
                    'phone' => $location->phone,
                    'email' => $location->email,
                    'timings' => json_decode($location->timings, true) ?: array(),
                    'facilities' => json_decode($location->facilities, true) ?: array(),
                    'status' => $location->status
                );
            }, $locations);
            
            return rest_ensure_response($formatted_locations);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get single location
     */
    public function get_location($request) {
        try {
            $location_id = $request->get_param('id');
            $location = $this->database->get_location($location_id);
            
            if (!$location) {
                return new WP_Error('location_not_found', __('Location not found', 'marine-world-booking'), array('status' => 404));
            }
            
            $formatted_location = array(
                'id' => (int) $location->id,
                'name' => $location->name,
                'address' => $location->address,
                'city' => $location->city,
                'state' => $location->state,
                'pincode' => $location->pincode,
                'phone' => $location->phone,
                'email' => $location->email,
                'timings' => json_decode($location->timings, true) ?: array(),
                'facilities' => json_decode($location->facilities, true) ?: array(),
                'status' => $location->status
            );
            
            return rest_ensure_response($formatted_location);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get availability
     */
    public function get_availability($request) {
        try {
            $location_id = $request->get_param('location_id');
            $date_from = $request->get_param('date_from');
            $date_to = $request->get_param('date_to') ?: $date_from;
            
            // Check cache first
            $cache_key = 'mwb_availability_' . md5($location_id . $date_from . $date_to);
            $cached_data = wp_cache_get($cache_key, 'marine_world');
            
            if ($cached_data !== false) {
                return rest_ensure_response($cached_data);
            }
            
            $availability = $this->database->get_availability($location_id, $date_from, $date_to);
            
            if (empty($availability)) {
                return new WP_Error('no_availability', __('No availability data found', 'marine-world-booking'), array('status' => 404));
            }
            
            $formatted_availability = array_map(function($day) {
                return array(
                    'date' => $day->availability_date,
                    'total_capacity' => (int) $day->total_capacity,
                    'available_slots' => (int) $day->available_slots,
                    'booked_slots' => (int) $day->booked_slots,
                    'status' => $day->status,
                    'special_pricing' => $day->special_pricing ? (float) $day->special_pricing : null,
                    'is_blackout' => (bool) $day->is_blackout,
                    'notes' => $day->notes
                );
            }, $availability);
            
            // Cache for 5 minutes
            wp_cache_set($cache_key, $formatted_availability, 'marine_world', 300);
            
            return rest_ensure_response($formatted_availability);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Calculate pricing
     */
    public function calculate_pricing($request) {
        try {
            $tickets = $request->get_param('tickets');
            $addons = $request->get_param('addons') ?: array();
            $promo_code = $request->get_param('promo_code');
            $booking_date = $request->get_param('booking_date');
            
            // Base ticket prices
            $ticket_prices = array(
                'general' => 400,
                'child' => 280,
                'senior' => 350
            );
            
            // Calculate tickets subtotal
            $tickets_subtotal = 0;
            $total_tickets = 0;
            $ticket_breakdown = array();
            
            foreach ($tickets as $type => $quantity) {
                $quantity = (int) $quantity;
                if ($quantity > 0 && isset($ticket_prices[$type])) {
                    $price = $ticket_prices[$type];
                    $line_total = $price * $quantity;
                    $tickets_subtotal += $line_total;
                    $total_tickets += $quantity;
                    
                    $ticket_breakdown[$type] = array(
                        'quantity' => $quantity,
                        'price' => $price,
                        'total' => $line_total
                    );
                }
            }
            
            // Calculate addons subtotal
            $addons_subtotal = 0;
            $addon_breakdown = array();
            $addon_items = $this->database->get_addons();
            $addon_prices = array();
            
            foreach ($addon_items as $addon) {
                $addon_prices[$addon->id] = (float) $addon->price;
            }
            
            foreach ($addons as $addon_id => $quantity) {
                $quantity = (int) $quantity;
                if ($quantity > 0 && isset($addon_prices[$addon_id])) {
                    $price = $addon_prices[$addon_id];
                    $line_total = $price * $quantity;
                    $addons_subtotal += $line_total;
                    
                    $addon_breakdown[$addon_id] = array(
                        'quantity' => $quantity,
                        'price' => $price,
                        'total' => $line_total
                    );
                }
            }
            
            $subtotal = $tickets_subtotal + $addons_subtotal;
            
            // Apply group discounts
            $group_discount = 0;
            $group_discount_percentage = 0;
            
            if ($total_tickets >= 30) {
                $group_discount_percentage = get_option('mwb_group_discount_30', 10);
            } elseif ($total_tickets >= 15) {
                $group_discount_percentage = get_option('mwb_group_discount_15', 5);
            }
            
            if ($group_discount_percentage > 0) {
                $group_discount = ($subtotal * $group_discount_percentage) / 100;
            }
            
            // Apply promo code discount
            $promo_discount = 0;
            $promo_details = null;
            
            if ($promo_code) {
                $promo = $this->database->get_promo_code($promo_code);
                if ($promo) {
                    if ($promo->discount_type === 'percentage') {
                        $promo_discount = ($subtotal * $promo->discount_value) / 100;
                        if ($promo->maximum_discount && $promo_discount > $promo->maximum_discount) {
                            $promo_discount = $promo->maximum_discount;
                        }
                    } else {
                        $promo_discount = $promo->discount_value;
                    }
                    
                    $promo_details = array(
                        'code' => $promo->code,
                        'description' => $promo->description,
                        'discount_type' => $promo->discount_type,
                        'discount_value' => (float) $promo->discount_value,
                        'applied_discount' => $promo_discount
                    );
                }
            }
            
            // Use the higher discount (group or promo)
            $total_discount = max($group_discount, $promo_discount);
            $discount_type = $group_discount > $promo_discount ? 'group' : 'promo';
            
            $final_total = max(0, $subtotal - $total_discount);
            
            $response = array(
                'subtotal' => $subtotal,
                'tickets_subtotal' => $tickets_subtotal,
                'addons_subtotal' => $addons_subtotal,
                'group_discount' => $group_discount,
                'group_discount_percentage' => $group_discount_percentage,
                'promo_discount' => $promo_discount,
                'total_discount' => $total_discount,
                'discount_type' => $discount_type,
                'final_total' => $final_total,
                'total_tickets' => $total_tickets,
                'breakdown' => array(
                    'tickets' => $ticket_breakdown,
                    'addons' => $addon_breakdown
                ),
                'promo_details' => $promo_details,
                'currency' => get_option('mwb_currency', '₹')
            );
            
            return rest_ensure_response($response);
            
        } catch (Exception $e) {
            return new WP_Error('pricing_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Validate promo code
     */
    public function validate_promo_code($request) {
        try {
            $code = $request->get_param('code');
            $amount = (float) $request->get_param('amount');
            
            $promo = $this->database->get_promo_code($code);
            
            if (!$promo) {
                return new WP_Error('invalid_promo', __('Invalid promo code', 'marine-world-booking'), array('status' => 400));
            }
            
            // Check usage limit
            if ($promo->usage_limit && $promo->used_count >= $promo->usage_limit) {
                return new WP_Error('promo_limit_exceeded', __('Promo code usage limit exceeded', 'marine-world-booking'), array('status' => 400));
            }
            
            // Check minimum amount
            if ($promo->minimum_amount && $amount < $promo->minimum_amount) {
                return new WP_Error('minimum_amount_not_met', 
                    sprintf(__('Minimum amount of %s%s required', 'marine-world-booking'), 
                           get_option('mwb_currency', '₹'), 
                           number_format($promo->minimum_amount, 2)),
                    array('status' => 400)
                );
            }
            
            return rest_ensure_response(array(
                'valid' => true,
                'code' => $promo->code,
                'description' => $promo->description,
                'discount_type' => $promo->discount_type,
                'discount_value' => (float) $promo->discount_value,
                'maximum_discount' => $promo->maximum_discount ? (float) $promo->maximum_discount : null,
                'minimum_amount' => (float) $promo->minimum_amount
            ));
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get add-ons
     */
    public function get_addons($request) {
        try {
            $addons = $this->database->get_addons();
            
            $formatted_addons = array_map(function($addon) {
                return array(
                    'id' => (int) $addon->id,
                    'name' => $addon->name,
                    'description' => $addon->description,
                    'price' => (float) $addon->price,
                    'display_order' => (int) $addon->display_order
                );
            }, $addons);
            
            return rest_ensure_response($formatted_addons);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Create booking
     */
    public function create_booking($request) {
        try {
            // Get and validate parameters
            $location_id = (int) $request->get_param('location_id');
            $booking_date = $request->get_param('booking_date');
            $customer_name = sanitize_text_field($request->get_param('customer_name'));
            $customer_email = sanitize_email($request->get_param('customer_email'));
            $customer_phone = sanitize_text_field($request->get_param('customer_phone'));
            $customer_pincode = sanitize_text_field($request->get_param('customer_pincode'));
            $tickets = $request->get_param('tickets');
            $addons = $request->get_param('addons') ?: array();
            $promo_code = $request->get_param('promo_code');
            
            // Validate required fields
            if (empty($customer_name) || empty($customer_email) || empty($customer_phone)) {
                return new WP_Error('missing_required_fields', __('Missing required customer information', 'marine-world-booking'), array('status' => 400));
            }
            
            if (!is_email($customer_email)) {
                return new WP_Error('invalid_email', __('Invalid email address', 'marine-world-booking'), array('status' => 400));
            }
            
            // Check availability
            $availability = $this->database->get_availability($location_id, $booking_date, $booking_date);
            if (empty($availability) || $availability[0]->status === 'sold_out' || $availability[0]->is_blackout) {
                return new WP_Error('not_available', __('Selected date is not available', 'marine-world-booking'), array('status' => 400));
            }
            
            // Calculate total tickets
            $total_tickets = 0;
            foreach ($tickets as $type => $quantity) {
                $total_tickets += (int) $quantity;
            }
            
            if ($total_tickets <= 0) {
                return new WP_Error('no_tickets', __('At least one ticket must be selected', 'marine-world-booking'), array('status' => 400));
            }
            
            // Check if enough slots available
            if ($availability[0]->available_slots < $total_tickets) {
                return new WP_Error('insufficient_availability', 
                    sprintf(__('Only %d tickets available', 'marine-world-booking'), $availability[0]->available_slots),
                    array('status' => 400)
                );
            }
            
            // Calculate pricing
            $pricing_request = new WP_REST_Request('POST');
            $pricing_request->set_param('tickets', $tickets);
            $pricing_request->set_param('addons', $addons);
            $pricing_request->set_param('promo_code', $promo_code);
            $pricing_request->set_param('booking_date', $booking_date);
            
            $pricing_response = $this->calculate_pricing($pricing_request);
            
            if (is_wp_error($pricing_response)) {
                return $pricing_response;
            }
            
            $pricing_data = $pricing_response->get_data();
            
            // Prepare booking data
            $booking_data = array(
                'location_id' => $location_id,
                'booking_date' => $booking_date,
                'customer_name' => $customer_name,
                'customer_email' => $customer_email,
                'customer_phone' => $customer_phone,
                'customer_pincode' => $customer_pincode,
                'general_tickets' => (int) ($tickets['general'] ?? 0),
                'child_tickets' => (int) ($tickets['child'] ?? 0),
                'senior_tickets' => (int) ($tickets['senior'] ?? 0),
                'addons_data' => json_encode($addons),
                'subtotal' => $pricing_data['subtotal'],
                'discount_amount' => $pricing_data['total_discount'],
                'discount_type' => $pricing_data['discount_type'],
                'promo_code' => $promo_code,
                'total_amount' => $pricing_data['final_total'],
                'payment_status' => 'pending',
                'booking_status' => 'pending'
            );
            
            // Handle third party booking
            if ($request->get_param('third_party_booking')) {
                $booking_data['third_party_booking'] = 1;
                $booking_data['third_party_name'] = sanitize_text_field($request->get_param('third_party_name'));
                $booking_data['third_party_email'] = sanitize_email($request->get_param('third_party_email'));
                $booking_data['third_party_phone'] = sanitize_text_field($request->get_param('third_party_phone'));
            }
            
            // Create booking
            $booking_id = $this->database->create_booking($booking_data);
            
            if (!$booking_id) {
                return new WP_Error('booking_creation_failed', __('Failed to create booking', 'marine-world-booking'), array('status' => 500));
            }
            
            // Clear availability cache
            $cache_key = 'mwb_availability_' . md5($location_id . $booking_date . $booking_date);
            wp_cache_delete($cache_key, 'marine_world');
            
            // Use promo code if provided and valid
            if ($promo_code && $pricing_data['promo_details']) {
                $this->database->use_promo_code($promo_code);
            }
            
            return rest_ensure_response(array(
                'success' => true,
                'booking_id' => $booking_id,
                'total_amount' => $pricing_data['final_total'],
                'currency' => get_option('mwb_currency', '₹'),
                'payment_required' => true,
                'message' => __('Booking created successfully', 'marine-world-booking')
            ));
            
        } catch (Exception $e) {
            return new WP_Error('booking_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Get booking details
     */
    public function get_booking($request) {
        try {
            $booking_id = $request->get_param('booking_id');
            $booking = $this->database->get_booking($booking_id);
            
            if (!$booking) {
                return new WP_Error('booking_not_found', __('Booking not found', 'marine-world-booking'), array('status' => 404));
            }
            
            $formatted_booking = array(
                'booking_id' => $booking->booking_id,
                'location_id' => (int) $booking->location_id,
                'booking_date' => $booking->booking_date,
                'customer_name' => $booking->customer_name,
                'customer_email' => $booking->customer_email,
                'customer_phone' => $booking->customer_phone,
                'customer_pincode' => $booking->customer_pincode,
                'third_party_booking' => (bool) $booking->third_party_booking,
                'third_party_name' => $booking->third_party_name,
                'third_party_email' => $booking->third_party_email,
                'third_party_phone' => $booking->third_party_phone,
                'tickets' => array(
                    'general' => (int) $booking->general_tickets,
                    'child' => (int) $booking->child_tickets,
                    'senior' => (int) $booking->senior_tickets
                ),
                'addons' => json_decode($booking->addons_data, true) ?: array(),
                'subtotal' => (float) $booking->subtotal,
                'discount_amount' => (float) $booking->discount_amount,
                'discount_type' => $booking->discount_type,
                'promo_code' => $booking->promo_code,
                'total_amount' => (float) $booking->total_amount,
                'payment_status' => $booking->payment_status,
                'payment_id' => $booking->payment_id,
                'payment_method' => $booking->payment_method,
                'booking_status' => $booking->booking_status,
                'qr_code' => $booking->qr_code,
                'tickets_claimed' => (bool) $booking->tickets_claimed,
                'claimed_at' => $booking->claimed_at,
                'created_at' => $booking->created_at,
                'updated_at' => $booking->updated_at
            );
            
            return rest_ensure_response($formatted_booking);
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Confirm payment
     */
    public function confirm_payment($request) {
        try {
            $booking_id = $request->get_param('booking_id');
            $payment_id = $request->get_param('payment_id');
            $payment_status = $request->get_param('payment_status');
            
            if ($payment_status === 'success' || $payment_status === 'completed') {
                $result = $this->database->update_booking_status($booking_id, 'confirmed', $payment_id);
                
                if ($result) {
                    // Send confirmation notifications
                    $this->send_booking_confirmations($booking_id);
                    
                    // Clear availability cache
                    $booking = $this->database->get_booking($booking_id);
                    if ($booking) {
                        $cache_key = 'mwb_availability_' . md5($booking->location_id . $booking->booking_date . $booking->booking_date);
                        wp_cache_delete($cache_key, 'marine_world');
                    }
                    
                    return rest_ensure_response(array(
                        'success' => true,
                        'message' => __('Payment confirmed successfully', 'marine-world-booking'),
                        'booking_status' => 'confirmed'
                    ));
                }
            }
            
            return new WP_Error('payment_confirmation_failed', __('Payment confirmation failed', 'marine-world-booking'), array('status' => 400));
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Admin endpoints
     */
    public function get_admin_bookings($request) {
        try {
            $page = (int) $request->get_param('page');
            $per_page = (int) $request->get_param('per_page');
            $offset = ($page - 1) * $per_page;
            
            $filters = array(
                'date_from' => $request->get_param('date_from'),
                'date_to' => $request->get_param('date_to'),
                'location_id' => $request->get_param('location_id'),
                'status' => $request->get_param('status')
            );
            
            $bookings = $this->database->get_bookings($per_page, $offset, $filters);
            
            $formatted_bookings = array_map(function($booking) {
                return array(
                    'id' => (int) $booking->id,
                    'booking_id' => $booking->booking_id,
                    'location_id' => (int) $booking->location_id,
                    'booking_date' => $booking->booking_date,
                    'customer_name' => $booking->customer_name,
                    'customer_email' => $booking->customer_email,
                    'customer_phone' => $booking->customer_phone,
                    'total_tickets' => (int) $booking->general_tickets + (int) $booking->child_tickets + (int) $booking->senior_tickets,
                    'total_amount' => (float) $booking->total_amount,
                    'payment_status' => $booking->payment_status,
                    'booking_status' => $booking->booking_status,
                    'created_at' => $booking->created_at
                );
            }, $bookings);
            
            // Get total count for pagination
            global $wpdb;
            $bookings_table = $wpdb->prefix . 'mwb_bookings';
            $total_count = $wpdb->get_var("SELECT COUNT(*) FROM {$bookings_table}");
            
            return rest_ensure_response(array(
                'bookings' => $formatted_bookings,
                'pagination' => array(
                    'total_count' => (int) $total_count,
                    'total_pages' => ceil($total_count / $per_page),
                    'current_page' => $page,
                    'per_page' => $per_page
                )
            ));
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    public function get_admin_stats($request) {
        try {
            $location_id = $request->get_param('location_id');
            $date_from = $request->get_param('date_from');
            $date_to = $request->get_param('date_to');
            
            $stats = $this->database->get_booking_stats($location_id, $date_from, $date_to);
            
            return rest_ensure_response(array(
                'total_bookings' => (int) ($stats->total_bookings ?? 0),
                'total_revenue' => (float) ($stats->total_revenue ?? 0),
                'total_tickets' => (int) ($stats->total_tickets ?? 0),
                'average_booking_value' => (float) ($stats->average_booking_value ?? 0),
                'unique_customers' => (int) ($stats->unique_customers ?? 0),
                'currency' => get_option('mwb_currency', '₹')
            ));
            
        } catch (Exception $e) {
            return new WP_Error('api_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    /**
     * Helper methods
     */
    public function validate_date($param) {
        return !empty($param) && (bool) strtotime($param);
    }
    
    public function check_admin_permission() {
        return current_user_can('manage_options');
    }
    
    private function send_booking_confirmations($booking_id) {
        $booking = $this->database->get_booking($booking_id);
        
        if ($booking && class_exists('MWB_Notification_Manager')) {
            $notification_manager = new MWB_Notification_Manager();
            $notification_manager->send_booking_confirmation($booking);
        }
    }
}